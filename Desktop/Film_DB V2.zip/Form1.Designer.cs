﻿namespace Film_DB_V2
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tbcMain = new System.Windows.Forms.TabControl();
            this.tbpList = new System.Windows.Forms.TabPage();
            this.pbxEdit = new System.Windows.Forms.PictureBox();
            this.lblDelmode = new System.Windows.Forms.Label();
            this.livMedia = new System.Windows.Forms.ListView();
            this.img1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.img2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.img3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.img4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.imlContentPics = new System.Windows.Forms.ImageList(this.components);
            this.btnFilter = new System.Windows.Forms.Button();
            this.tbxSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.cbxWishList = new System.Windows.Forms.CheckBox();
            this.cbxAnime = new System.Windows.Forms.CheckBox();
            this.cbxSeries = new System.Windows.Forms.CheckBox();
            this.cbxMovie = new System.Windows.Forms.CheckBox();
            this.btnSuggest = new System.Windows.Forms.Button();
            this.tbpNew = new System.Windows.Forms.TabPage();
            this.pbxOK = new System.Windows.Forms.PictureBox();
            this.pbxPreview = new System.Windows.Forms.PictureBox();
            this.dtpWatchdate = new System.Windows.Forms.DateTimePicker();
            this.nudParts = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.rbnAnime = new System.Windows.Forms.RadioButton();
            this.rbnMovie = new System.Windows.Forms.RadioButton();
            this.rbnSeries = new System.Windows.Forms.RadioButton();
            this.nudRating = new System.Windows.Forms.NumericUpDown();
            this.cbxAddWishList = new System.Windows.Forms.CheckBox();
            this.tbxName = new System.Windows.Forms.TextBox();
            this.tbxLink = new System.Windows.Forms.TextBox();
            this.btnImageSelect = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.a = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tmrHide = new System.Windows.Forms.Timer(this.components);
            this.ofdImageSelect = new System.Windows.Forms.OpenFileDialog();
            this.ttpInfo = new System.Windows.Forms.ToolTip(this.components);
            this.pbxInfo = new System.Windows.Forms.PictureBox();
            this.tbcMain.SuspendLayout();
            this.tbpList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEdit)).BeginInit();
            this.tbpNew.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPreview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudParts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRating)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // tbcMain
            // 
            this.tbcMain.Controls.Add(this.tbpList);
            this.tbcMain.Controls.Add(this.tbpNew);
            this.tbcMain.Location = new System.Drawing.Point(-1, -1);
            this.tbcMain.Name = "tbcMain";
            this.tbcMain.SelectedIndex = 0;
            this.tbcMain.Size = new System.Drawing.Size(1112, 644);
            this.tbcMain.TabIndex = 0;
            this.tbcMain.MouseMove += new System.Windows.Forms.MouseEventHandler(this.TbcMain_MouseMove);
            // 
            // tbpList
            // 
            this.tbpList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.tbpList.Controls.Add(this.pbxInfo);
            this.tbpList.Controls.Add(this.pbxEdit);
            this.tbpList.Controls.Add(this.lblDelmode);
            this.tbpList.Controls.Add(this.livMedia);
            this.tbpList.Controls.Add(this.btnFilter);
            this.tbpList.Controls.Add(this.tbxSearch);
            this.tbpList.Controls.Add(this.btnSearch);
            this.tbpList.Controls.Add(this.btnDelete);
            this.tbpList.Controls.Add(this.cbxWishList);
            this.tbpList.Controls.Add(this.cbxAnime);
            this.tbpList.Controls.Add(this.cbxSeries);
            this.tbpList.Controls.Add(this.cbxMovie);
            this.tbpList.Controls.Add(this.btnSuggest);
            this.tbpList.Location = new System.Drawing.Point(4, 22);
            this.tbpList.Name = "tbpList";
            this.tbpList.Padding = new System.Windows.Forms.Padding(3);
            this.tbpList.Size = new System.Drawing.Size(1104, 618);
            this.tbpList.TabIndex = 0;
            this.tbpList.Text = "Liste";
            // 
            // pbxEdit
            // 
            this.pbxEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.pbxEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxEdit.BackgroundImage")));
            this.pbxEdit.Location = new System.Drawing.Point(719, 12);
            this.pbxEdit.Name = "pbxEdit";
            this.pbxEdit.Size = new System.Drawing.Size(33, 34);
            this.pbxEdit.TabIndex = 54;
            this.pbxEdit.TabStop = false;
            this.pbxEdit.Click += new System.EventHandler(this.PbxEdit_Click);
            // 
            // lblDelmode
            // 
            this.lblDelmode.AutoSize = true;
            this.lblDelmode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDelmode.ForeColor = System.Drawing.Color.Red;
            this.lblDelmode.Location = new System.Drawing.Point(761, 80);
            this.lblDelmode.Name = "lblDelmode";
            this.lblDelmode.Size = new System.Drawing.Size(132, 16);
            this.lblDelmode.TabIndex = 53;
            this.lblDelmode.Text = "Löschmodus aktiv";
            this.lblDelmode.Visible = false;
            // 
            // livMedia
            // 
            this.livMedia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.livMedia.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.livMedia.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.img1,
            this.img2,
            this.img3,
            this.img4});
            this.livMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.livMedia.ForeColor = System.Drawing.Color.White;
            this.livMedia.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.livMedia.HideSelection = false;
            this.livMedia.LargeImageList = this.imlContentPics;
            this.livMedia.Location = new System.Drawing.Point(3, 130);
            this.livMedia.MultiSelect = false;
            this.livMedia.Name = "livMedia";
            this.livMedia.Size = new System.Drawing.Size(1098, 485);
            this.livMedia.SmallImageList = this.imlContentPics;
            this.livMedia.TabIndex = 52;
            this.livMedia.UseCompatibleStateImageBehavior = false;
            this.livMedia.ItemMouseHover += new System.Windows.Forms.ListViewItemMouseHoverEventHandler(this.LivMedia_ItemMouseHover);
            this.livMedia.SelectedIndexChanged += new System.EventHandler(this.LivMedia_SelectedIndexChanged);
            this.livMedia.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.LivMedia_MouseDoubleClick);
            this.livMedia.MouseHover += new System.EventHandler(this.LivMedia_MouseHover);
            // 
            // imlContentPics
            // 
            this.imlContentPics.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imlContentPics.ImageSize = new System.Drawing.Size(256, 256);
            this.imlContentPics.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // btnFilter
            // 
            this.btnFilter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.btnFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFilter.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnFilter.Location = new System.Drawing.Point(240, 16);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(200, 58);
            this.btnFilter.TabIndex = 21;
            this.btnFilter.Text = "Filtern";
            this.btnFilter.UseVisualStyleBackColor = false;
            this.btnFilter.Click += new System.EventHandler(this.BtnFilter_Click);
            // 
            // tbxSearch
            // 
            this.tbxSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.tbxSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbxSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbxSearch.Location = new System.Drawing.Point(837, 20);
            this.tbxSearch.Name = "tbxSearch";
            this.tbxSearch.Size = new System.Drawing.Size(240, 20);
            this.tbxSearch.TabIndex = 29;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.btnSearch.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnSearch.Image = ((System.Drawing.Image)(resources.GetObject("btnSearch.Image")));
            this.btnSearch.Location = new System.Drawing.Point(789, 8);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(42, 39);
            this.btnSearch.TabIndex = 28;
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.btnDelete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(750, 6);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(40, 41);
            this.btnDelete.TabIndex = 27;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // cbxWishList
            // 
            this.cbxWishList.AutoSize = true;
            this.cbxWishList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxWishList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.cbxWishList.Location = new System.Drawing.Point(34, 105);
            this.cbxWishList.Name = "cbxWishList";
            this.cbxWishList.Size = new System.Drawing.Size(103, 19);
            this.cbxWishList.TabIndex = 25;
            this.cbxWishList.Text = "Wunschliste";
            this.cbxWishList.UseVisualStyleBackColor = true;
            this.cbxWishList.CheckedChanged += new System.EventHandler(this.CbxWishList_CheckedChanged);
            // 
            // cbxAnime
            // 
            this.cbxAnime.AutoSize = true;
            this.cbxAnime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxAnime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.cbxAnime.Location = new System.Drawing.Point(159, 80);
            this.cbxAnime.Name = "cbxAnime";
            this.cbxAnime.Size = new System.Drawing.Size(66, 19);
            this.cbxAnime.TabIndex = 24;
            this.cbxAnime.Text = "Anime";
            this.cbxAnime.UseVisualStyleBackColor = true;
            this.cbxAnime.CheckedChanged += new System.EventHandler(this.CbxAnime_CheckedChanged);
            // 
            // cbxSeries
            // 
            this.cbxSeries.AutoSize = true;
            this.cbxSeries.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxSeries.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.cbxSeries.Location = new System.Drawing.Point(94, 80);
            this.cbxSeries.Name = "cbxSeries";
            this.cbxSeries.Size = new System.Drawing.Size(60, 19);
            this.cbxSeries.TabIndex = 23;
            this.cbxSeries.Text = "Serie";
            this.cbxSeries.UseVisualStyleBackColor = true;
            this.cbxSeries.CheckedChanged += new System.EventHandler(this.CbxSeries_CheckedChanged);
            // 
            // cbxMovie
            // 
            this.cbxMovie.AutoSize = true;
            this.cbxMovie.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxMovie.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.cbxMovie.Location = new System.Drawing.Point(34, 80);
            this.cbxMovie.Name = "cbxMovie";
            this.cbxMovie.Size = new System.Drawing.Size(54, 19);
            this.cbxMovie.TabIndex = 22;
            this.cbxMovie.Text = "Film";
            this.cbxMovie.UseVisualStyleBackColor = true;
            this.cbxMovie.CheckedChanged += new System.EventHandler(this.CbxMovie_CheckedChanged);
            // 
            // btnSuggest
            // 
            this.btnSuggest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.btnSuggest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuggest.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuggest.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnSuggest.Location = new System.Drawing.Point(25, 16);
            this.btnSuggest.Name = "btnSuggest";
            this.btnSuggest.Size = new System.Drawing.Size(200, 58);
            this.btnSuggest.TabIndex = 21;
            this.btnSuggest.Text = "Vorschlag";
            this.btnSuggest.UseVisualStyleBackColor = false;
            this.btnSuggest.Click += new System.EventHandler(this.BtnSuggest_Click);
            // 
            // tbpNew
            // 
            this.tbpNew.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.tbpNew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.tbpNew.Controls.Add(this.pbxOK);
            this.tbpNew.Controls.Add(this.pbxPreview);
            this.tbpNew.Controls.Add(this.dtpWatchdate);
            this.tbpNew.Controls.Add(this.nudParts);
            this.tbpNew.Controls.Add(this.label11);
            this.tbpNew.Controls.Add(this.label8);
            this.tbpNew.Controls.Add(this.label7);
            this.tbpNew.Controls.Add(this.label6);
            this.tbpNew.Controls.Add(this.label5);
            this.tbpNew.Controls.Add(this.rbnAnime);
            this.tbpNew.Controls.Add(this.rbnMovie);
            this.tbpNew.Controls.Add(this.rbnSeries);
            this.tbpNew.Controls.Add(this.nudRating);
            this.tbpNew.Controls.Add(this.cbxAddWishList);
            this.tbpNew.Controls.Add(this.tbxName);
            this.tbpNew.Controls.Add(this.tbxLink);
            this.tbpNew.Controls.Add(this.btnImageSelect);
            this.tbpNew.Controls.Add(this.btnSave);
            this.tbpNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbpNew.Location = new System.Drawing.Point(4, 22);
            this.tbpNew.Name = "tbpNew";
            this.tbpNew.Padding = new System.Windows.Forms.Padding(3);
            this.tbpNew.Size = new System.Drawing.Size(1104, 618);
            this.tbpNew.TabIndex = 1;
            this.tbpNew.Text = "neuer Eintrag";
            // 
            // pbxOK
            // 
            this.pbxOK.Image = ((System.Drawing.Image)(resources.GetObject("pbxOK.Image")));
            this.pbxOK.Location = new System.Drawing.Point(89, 32);
            this.pbxOK.Name = "pbxOK";
            this.pbxOK.Size = new System.Drawing.Size(36, 36);
            this.pbxOK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxOK.TabIndex = 51;
            this.pbxOK.TabStop = false;
            this.pbxOK.Visible = false;
            // 
            // pbxPreview
            // 
            this.pbxPreview.Location = new System.Drawing.Point(844, 16);
            this.pbxPreview.Name = "pbxPreview";
            this.pbxPreview.Size = new System.Drawing.Size(237, 376);
            this.pbxPreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxPreview.TabIndex = 50;
            this.pbxPreview.TabStop = false;
            // 
            // dtpWatchdate
            // 
            this.dtpWatchdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpWatchdate.Location = new System.Drawing.Point(129, 233);
            this.dtpWatchdate.Name = "dtpWatchdate";
            this.dtpWatchdate.Size = new System.Drawing.Size(140, 21);
            this.dtpWatchdate.TabIndex = 49;
            // 
            // nudParts
            // 
            this.nudParts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.nudParts.Enabled = false;
            this.nudParts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.nudParts.Location = new System.Drawing.Point(447, 233);
            this.nudParts.Name = "nudParts";
            this.nudParts.Size = new System.Drawing.Size(53, 21);
            this.nudParts.TabIndex = 48;
            this.nudParts.ValueChanged += new System.EventHandler(this.NudParts_ValueChanged);
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label11.Location = new System.Drawing.Point(366, 227);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(89, 30);
            this.label11.TabIndex = 47;
            this.label11.Text = "Staffeln";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label8.Location = new System.Drawing.Point(19, 227);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 30);
            this.label8.TabIndex = 42;
            this.label8.Text = "geschaut am";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label7.Location = new System.Drawing.Point(19, 186);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 30);
            this.label7.TabIndex = 41;
            this.label7.Text = "Bewertung";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label6.Location = new System.Drawing.Point(-2, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 30);
            this.label6.TabIndex = 40;
            this.label6.Text = "Link";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label5.Location = new System.Drawing.Point(6, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 30);
            this.label5.TabIndex = 39;
            this.label5.Text = "Name:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rbnAnime
            // 
            this.rbnAnime.AutoSize = true;
            this.rbnAnime.BackColor = System.Drawing.Color.Red;
            this.rbnAnime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.rbnAnime.Location = new System.Drawing.Point(537, 192);
            this.rbnAnime.Name = "rbnAnime";
            this.rbnAnime.Size = new System.Drawing.Size(65, 19);
            this.rbnAnime.TabIndex = 38;
            this.rbnAnime.TabStop = true;
            this.rbnAnime.Text = "Anime";
            this.rbnAnime.UseVisualStyleBackColor = false;
            this.rbnAnime.CheckedChanged += new System.EventHandler(this.RbnAnime_CheckedChanged);
            // 
            // rbnMovie
            // 
            this.rbnMovie.AutoSize = true;
            this.rbnMovie.BackColor = System.Drawing.Color.Red;
            this.rbnMovie.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.rbnMovie.Location = new System.Drawing.Point(459, 192);
            this.rbnMovie.Name = "rbnMovie";
            this.rbnMovie.Size = new System.Drawing.Size(61, 19);
            this.rbnMovie.TabIndex = 37;
            this.rbnMovie.TabStop = true;
            this.rbnMovie.Text = "Filme";
            this.rbnMovie.UseVisualStyleBackColor = false;
            this.rbnMovie.CheckedChanged += new System.EventHandler(this.RbnMovie_CheckedChanged);
            // 
            // rbnSeries
            // 
            this.rbnSeries.AutoSize = true;
            this.rbnSeries.BackColor = System.Drawing.Color.Red;
            this.rbnSeries.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.rbnSeries.Location = new System.Drawing.Point(384, 192);
            this.rbnSeries.Name = "rbnSeries";
            this.rbnSeries.Size = new System.Drawing.Size(59, 19);
            this.rbnSeries.TabIndex = 36;
            this.rbnSeries.TabStop = true;
            this.rbnSeries.Text = "Serie";
            this.rbnSeries.UseVisualStyleBackColor = false;
            this.rbnSeries.CheckedChanged += new System.EventHandler(this.RbnSeries_CheckedChanged);
            // 
            // nudRating
            // 
            this.nudRating.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.nudRating.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.nudRating.Location = new System.Drawing.Point(129, 192);
            this.nudRating.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudRating.Name = "nudRating";
            this.nudRating.Size = new System.Drawing.Size(203, 21);
            this.nudRating.TabIndex = 35;
            // 
            // cbxAddWishList
            // 
            this.cbxAddWishList.AutoSize = true;
            this.cbxAddWishList.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.cbxAddWishList.Location = new System.Drawing.Point(22, 277);
            this.cbxAddWishList.Name = "cbxAddWishList";
            this.cbxAddWishList.Size = new System.Drawing.Size(103, 19);
            this.cbxAddWishList.TabIndex = 33;
            this.cbxAddWishList.Text = "Wunschliste";
            this.cbxAddWishList.UseVisualStyleBackColor = true;
            this.cbxAddWishList.CheckedChanged += new System.EventHandler(this.CbxAddWishList_CheckedChanged);
            // 
            // tbxName
            // 
            this.tbxName.BackColor = System.Drawing.Color.Red;
            this.tbxName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbxName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbxName.Location = new System.Drawing.Point(129, 132);
            this.tbxName.Name = "tbxName";
            this.tbxName.Size = new System.Drawing.Size(482, 21);
            this.tbxName.TabIndex = 32;
            this.tbxName.TextChanged += new System.EventHandler(this.TbxName_TextChanged);
            // 
            // tbxLink
            // 
            this.tbxLink.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.tbxLink.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbxLink.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.tbxLink.Location = new System.Drawing.Point(129, 162);
            this.tbxLink.Name = "tbxLink";
            this.tbxLink.Size = new System.Drawing.Size(482, 21);
            this.tbxLink.TabIndex = 31;
            // 
            // btnImageSelect
            // 
            this.btnImageSelect.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.btnImageSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImageSelect.Image = ((System.Drawing.Image)(resources.GetObject("btnImageSelect.Image")));
            this.btnImageSelect.Location = new System.Drawing.Point(629, 16);
            this.btnImageSelect.Name = "btnImageSelect";
            this.btnImageSelect.Size = new System.Drawing.Size(69, 64);
            this.btnImageSelect.TabIndex = 1;
            this.btnImageSelect.UseVisualStyleBackColor = true;
            this.btnImageSelect.Click += new System.EventHandler(this.BtnImageSelect_Click);
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(18, 16);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(64, 64);
            this.btnSave.TabIndex = 0;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // a
            // 
            this.a.Location = new System.Drawing.Point(40, 50);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(237, 376);
            this.a.TabIndex = 30;
            this.a.TabStop = false;
            // 
            // label12
            // 
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label12.Location = new System.Drawing.Point(843, 1034);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(237, 30);
            this.label12.TabIndex = 20;
            this.label12.Text = "Film";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label13.Location = new System.Drawing.Point(31, 1034);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(237, 30);
            this.label13.TabIndex = 21;
            this.label13.Text = "Film";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label14.Location = new System.Drawing.Point(301, 1034);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(237, 30);
            this.label14.TabIndex = 22;
            this.label14.Text = "Film";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label15.Location = new System.Drawing.Point(573, 1034);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(237, 30);
            this.label15.TabIndex = 23;
            this.label15.Text = "Film";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tmrHide
            // 
            this.tmrHide.Interval = 2000;
            this.tmrHide.Tick += new System.EventHandler(this.TmrHide_Tick);
            // 
            // ofdImageSelect
            // 
            this.ofdImageSelect.FileName = "openFileDialog1";
            // 
            // pbxInfo
            // 
            this.pbxInfo.BackColor = System.Drawing.Color.White;
            this.pbxInfo.Location = new System.Drawing.Point(680, 13);
            this.pbxInfo.Name = "pbxInfo";
            this.pbxInfo.Size = new System.Drawing.Size(33, 34);
            this.pbxInfo.TabIndex = 55;
            this.pbxInfo.TabStop = false;
            this.pbxInfo.Click += new System.EventHandler(this.PbxInfo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(57)))), ((int)(((byte)(63)))));
            this.ClientSize = new System.Drawing.Size(1111, 637);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.tbcMain);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Film_DB";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tbcMain.ResumeLayout(false);
            this.tbpList.ResumeLayout(false);
            this.tbpList.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxEdit)).EndInit();
            this.tbpNew.ResumeLayout(false);
            this.tbpNew.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxOK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPreview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudParts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRating)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxInfo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbcMain;
        private System.Windows.Forms.TabPage tbpNew;
        private System.Windows.Forms.Button btnImageSelect;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rbnAnime;
        private System.Windows.Forms.RadioButton rbnMovie;
        private System.Windows.Forms.RadioButton rbnSeries;
        private System.Windows.Forms.NumericUpDown nudRating;
        private System.Windows.Forms.CheckBox cbxAddWishList;
        private System.Windows.Forms.TextBox tbxName;
        private System.Windows.Forms.TextBox tbxLink;
        private System.Windows.Forms.NumericUpDown nudParts;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dtpWatchdate;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tbpList;
        private System.Windows.Forms.Button btnFilter;
        private System.Windows.Forms.TextBox tbxSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.CheckBox cbxWishList;
        private System.Windows.Forms.CheckBox cbxAnime;
        private System.Windows.Forms.CheckBox cbxSeries;
        private System.Windows.Forms.CheckBox cbxMovie;
        private System.Windows.Forms.Button btnSuggest;
        private System.Windows.Forms.PictureBox a;
        private System.Windows.Forms.PictureBox pbxPreview;
        private System.Windows.Forms.ImageList imlContentPics;
        private System.Windows.Forms.ListView livMedia;
        private System.Windows.Forms.ColumnHeader img1;
        private System.Windows.Forms.ColumnHeader img2;
        private System.Windows.Forms.ColumnHeader img3;
        private System.Windows.Forms.ColumnHeader img4;
        private System.Windows.Forms.Label lblDelmode;
        private System.Windows.Forms.PictureBox pbxOK;
        private System.Windows.Forms.Timer tmrHide;
        private System.Windows.Forms.OpenFileDialog ofdImageSelect;
        private System.Windows.Forms.ToolTip ttpInfo;
        private System.Windows.Forms.PictureBox pbxEdit;
        private System.Windows.Forms.PictureBox pbxInfo;
    }
}

